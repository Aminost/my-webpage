# workshop-playground

A basic example, done as part of the workshop "Build your first website in 2 hours", coded on Stackblitz

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/js-maxrd9)
